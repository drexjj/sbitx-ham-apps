/****************************************************************************
** Meta object code from reading C++ file 'm17.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.4.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../m17.h"
#include <QtNetwork/QSslPreSharedKeyAuthenticator>
#include <QtNetwork/QSslError>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'm17.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.4.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
namespace {
struct qt_meta_stringdata_M17_t {
    uint offsetsAndSizes[68];
    char stringdata0[4];
    char stringdata1[12];
    char stringdata2[1];
    char stringdata3[19];
    char stringdata4[16];
    char stringdata5[10];
    char stringdata6[16];
    char stringdata7[10];
    char stringdata8[9];
    char stringdata9[9];
    char stringdata10[16];
    char stringdata11[10];
    char stringdata12[2];
    char stringdata13[21];
    char stringdata14[13];
    char stringdata15[2];
    char stringdata16[12];
    char stringdata17[2];
    char stringdata18[16];
    char stringdata19[18];
    char stringdata20[15];
    char stringdata21[10];
    char stringdata22[20];
    char stringdata23[9];
    char stringdata24[9];
    char stringdata25[23];
    char stringdata26[11];
    char stringdata27[12];
    char stringdata28[11];
    char stringdata29[3];
    char stringdata30[7];
    char stringdata31[12];
    char stringdata32[12];
    char stringdata33[9];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_M17_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_M17_t qt_meta_stringdata_M17 = {
    {
        QT_MOC_LITERAL(0, 3),  // "M17"
        QT_MOC_LITERAL(4, 11),  // "process_udp"
        QT_MOC_LITERAL(16, 0),  // ""
        QT_MOC_LITERAL(17, 18),  // "process_modem_data"
        QT_MOC_LITERAL(36, 15),  // "send_modem_data"
        QT_MOC_LITERAL(52, 9),  // "send_ping"
        QT_MOC_LITERAL(62, 15),  // "send_disconnect"
        QT_MOC_LITERAL(78, 9),  // "toggle_tx"
        QT_MOC_LITERAL(88, 8),  // "start_tx"
        QT_MOC_LITERAL(97, 8),  // "transmit"
        QT_MOC_LITERAL(106, 15),  // "hostname_lookup"
        QT_MOC_LITERAL(122, 9),  // "QHostInfo"
        QT_MOC_LITERAL(132, 1),  // "i"
        QT_MOC_LITERAL(134, 20),  // "mmdvm_direct_connect"
        QT_MOC_LITERAL(155, 12),  // "rate_changed"
        QT_MOC_LITERAL(168, 1),  // "r"
        QT_MOC_LITERAL(170, 11),  // "can_changed"
        QT_MOC_LITERAL(182, 1),  // "c"
        QT_MOC_LITERAL(184, 15),  // "process_rx_data"
        QT_MOC_LITERAL(200, 17),  // "splitFragmentLICH"
        QT_MOC_LITERAL(218, 14),  // "const uint8_t*"
        QT_MOC_LITERAL(233, 9),  // "uint32_t&"
        QT_MOC_LITERAL(243, 19),  // "combineFragmentLICH"
        QT_MOC_LITERAL(263, 8),  // "uint32_t"
        QT_MOC_LITERAL(272, 8),  // "uint8_t*"
        QT_MOC_LITERAL(281, 22),  // "combineFragmentLICHFEC"
        QT_MOC_LITERAL(304, 10),  // "interleave"
        QT_MOC_LITERAL(315, 11),  // "decorrelate"
        QT_MOC_LITERAL(327, 10),  // "checkCRC16"
        QT_MOC_LITERAL(338, 2),  // "in"
        QT_MOC_LITERAL(341, 6),  // "nBytes"
        QT_MOC_LITERAL(348, 11),  // "encodeCRC16"
        QT_MOC_LITERAL(360, 11),  // "createCRC16"
        QT_MOC_LITERAL(372, 8)   // "uint16_t"
    },
    "M17",
    "process_udp",
    "",
    "process_modem_data",
    "send_modem_data",
    "send_ping",
    "send_disconnect",
    "toggle_tx",
    "start_tx",
    "transmit",
    "hostname_lookup",
    "QHostInfo",
    "i",
    "mmdvm_direct_connect",
    "rate_changed",
    "r",
    "can_changed",
    "c",
    "process_rx_data",
    "splitFragmentLICH",
    "const uint8_t*",
    "uint32_t&",
    "combineFragmentLICH",
    "uint32_t",
    "uint8_t*",
    "combineFragmentLICHFEC",
    "interleave",
    "decorrelate",
    "checkCRC16",
    "in",
    "nBytes",
    "encodeCRC16",
    "createCRC16",
    "uint16_t"
};
#undef QT_MOC_LITERAL
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_M17[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      21,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  140,    2, 0x08,    1 /* Private */,
       3,    1,  141,    2, 0x08,    2 /* Private */,
       4,    1,  144,    2, 0x08,    4 /* Private */,
       5,    0,  147,    2, 0x08,    6 /* Private */,
       6,    0,  148,    2, 0x08,    7 /* Private */,
       7,    1,  149,    2, 0x08,    8 /* Private */,
       8,    0,  152,    2, 0x08,   10 /* Private */,
       9,    0,  153,    2, 0x08,   11 /* Private */,
      10,    1,  154,    2, 0x08,   12 /* Private */,
      13,    0,  157,    2, 0x08,   14 /* Private */,
      14,    1,  158,    2, 0x08,   15 /* Private */,
      16,    1,  161,    2, 0x08,   17 /* Private */,
      18,    0,  164,    2, 0x08,   19 /* Private */,
      19,    5,  165,    2, 0x08,   20 /* Private */,
      22,    5,  176,    2, 0x08,   26 /* Private */,
      25,    5,  187,    2, 0x08,   32 /* Private */,
      26,    2,  198,    2, 0x08,   38 /* Private */,
      27,    2,  203,    2, 0x08,   41 /* Private */,
      28,    2,  208,    2, 0x08,   44 /* Private */,
      31,    2,  213,    2, 0x08,   47 /* Private */,
      32,    2,  218,    2, 0x08,   50 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::QByteArray,    2,
    QMetaType::Void, QMetaType::QByteArray,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 11,   12,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   15,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 20, 0x80000000 | 21, 0x80000000 | 21, 0x80000000 | 21, 0x80000000 | 21,    2,    2,    2,    2,    2,
    QMetaType::Void, 0x80000000 | 23, 0x80000000 | 23, 0x80000000 | 23, 0x80000000 | 23, 0x80000000 | 24,    2,    2,    2,    2,    2,
    QMetaType::Void, 0x80000000 | 23, 0x80000000 | 23, 0x80000000 | 23, 0x80000000 | 23, 0x80000000 | 24,    2,    2,    2,    2,    2,
    QMetaType::Void, 0x80000000 | 24, 0x80000000 | 24,    2,    2,
    QMetaType::Void, 0x80000000 | 24, 0x80000000 | 24,    2,    2,
    QMetaType::Bool, 0x80000000 | 20, 0x80000000 | 23,   29,   30,
    QMetaType::Void, 0x80000000 | 24, 0x80000000 | 23,   29,   30,
    0x80000000 | 33, 0x80000000 | 20, 0x80000000 | 23,   29,   30,

       0        // eod
};

Q_CONSTINIT const QMetaObject M17::staticMetaObject = { {
    QMetaObject::SuperData::link<Mode::staticMetaObject>(),
    qt_meta_stringdata_M17.offsetsAndSizes,
    qt_meta_data_M17,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_M17_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<M17, std::true_type>,
        // method 'process_udp'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'process_modem_data'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QByteArray, std::false_type>,
        // method 'send_modem_data'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QByteArray, std::false_type>,
        // method 'send_ping'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'send_disconnect'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'toggle_tx'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'start_tx'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'transmit'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'hostname_lookup'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QHostInfo, std::false_type>,
        // method 'mmdvm_direct_connect'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'rate_changed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'can_changed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'process_rx_data'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'splitFragmentLICH'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const uint8_t *, std::false_type>,
        QtPrivate::TypeAndForceComplete<uint32_t &, std::false_type>,
        QtPrivate::TypeAndForceComplete<uint32_t &, std::false_type>,
        QtPrivate::TypeAndForceComplete<uint32_t &, std::false_type>,
        QtPrivate::TypeAndForceComplete<uint32_t &, std::false_type>,
        // method 'combineFragmentLICH'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<uint32_t, std::false_type>,
        QtPrivate::TypeAndForceComplete<uint32_t, std::false_type>,
        QtPrivate::TypeAndForceComplete<uint32_t, std::false_type>,
        QtPrivate::TypeAndForceComplete<uint32_t, std::false_type>,
        QtPrivate::TypeAndForceComplete<uint8_t *, std::false_type>,
        // method 'combineFragmentLICHFEC'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<uint32_t, std::false_type>,
        QtPrivate::TypeAndForceComplete<uint32_t, std::false_type>,
        QtPrivate::TypeAndForceComplete<uint32_t, std::false_type>,
        QtPrivate::TypeAndForceComplete<uint32_t, std::false_type>,
        QtPrivate::TypeAndForceComplete<uint8_t *, std::false_type>,
        // method 'interleave'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<uint8_t *, std::false_type>,
        QtPrivate::TypeAndForceComplete<uint8_t *, std::false_type>,
        // method 'decorrelate'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<uint8_t *, std::false_type>,
        QtPrivate::TypeAndForceComplete<uint8_t *, std::false_type>,
        // method 'checkCRC16'
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<const uint8_t *, std::false_type>,
        QtPrivate::TypeAndForceComplete<uint32_t, std::false_type>,
        // method 'encodeCRC16'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<uint8_t *, std::false_type>,
        QtPrivate::TypeAndForceComplete<uint32_t, std::false_type>,
        // method 'createCRC16'
        QtPrivate::TypeAndForceComplete<uint16_t, std::false_type>,
        QtPrivate::TypeAndForceComplete<const uint8_t *, std::false_type>,
        QtPrivate::TypeAndForceComplete<uint32_t, std::false_type>
    >,
    nullptr
} };

void M17::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<M17 *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->process_udp(); break;
        case 1: _t->process_modem_data((*reinterpret_cast< std::add_pointer_t<QByteArray>>(_a[1]))); break;
        case 2: _t->send_modem_data((*reinterpret_cast< std::add_pointer_t<QByteArray>>(_a[1]))); break;
        case 3: _t->send_ping(); break;
        case 4: _t->send_disconnect(); break;
        case 5: _t->toggle_tx((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 6: _t->start_tx(); break;
        case 7: _t->transmit(); break;
        case 8: _t->hostname_lookup((*reinterpret_cast< std::add_pointer_t<QHostInfo>>(_a[1]))); break;
        case 9: _t->mmdvm_direct_connect(); break;
        case 10: _t->rate_changed((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 11: _t->can_changed((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 12: _t->process_rx_data(); break;
        case 13: _t->splitFragmentLICH((*reinterpret_cast< std::add_pointer_t<const uint8_t*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<uint32_t&>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<uint32_t&>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<uint32_t&>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<uint32_t&>>(_a[5]))); break;
        case 14: _t->combineFragmentLICH((*reinterpret_cast< std::add_pointer_t<uint32_t>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<uint32_t>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<uint32_t>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<uint32_t>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<uint8_t*>>(_a[5]))); break;
        case 15: _t->combineFragmentLICHFEC((*reinterpret_cast< std::add_pointer_t<uint32_t>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<uint32_t>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<uint32_t>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<uint32_t>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<uint8_t*>>(_a[5]))); break;
        case 16: _t->interleave((*reinterpret_cast< std::add_pointer_t<uint8_t*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<uint8_t*>>(_a[2]))); break;
        case 17: _t->decorrelate((*reinterpret_cast< std::add_pointer_t<uint8_t*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<uint8_t*>>(_a[2]))); break;
        case 18: { bool _r = _t->checkCRC16((*reinterpret_cast< std::add_pointer_t<const uint8_t*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<uint32_t>>(_a[2])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 19: _t->encodeCRC16((*reinterpret_cast< std::add_pointer_t<uint8_t*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<uint32_t>>(_a[2]))); break;
        case 20: { uint16_t _r = _t->createCRC16((*reinterpret_cast< std::add_pointer_t<const uint8_t*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<uint32_t>>(_a[2])));
            if (_a[0]) *reinterpret_cast< uint16_t*>(_a[0]) = std::move(_r); }  break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 8:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QHostInfo >(); break;
            }
            break;
        }
    }
}

const QMetaObject *M17::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *M17::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_M17.stringdata0))
        return static_cast<void*>(this);
    return Mode::qt_metacast(_clname);
}

int M17::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = Mode::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 21)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 21;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 21)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 21;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
