/****************************************************************************
** Meta object code from reading C++ file 'droidstar.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.4.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../droidstar.h"
#include <QtNetwork/QSslPreSharedKeyAuthenticator>
#include <QtNetwork/QSslError>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'droidstar.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.4.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
namespace {
struct qt_meta_stringdata_DroidStar_t {
    uint offsetsAndSizes[522];
    char stringdata0[10];
    char stringdata1[21];
    char stringdata2[1];
    char stringdata3[13];
    char stringdata4[15];
    char stringdata5[13];
    char stringdata6[11];
    char stringdata7[12];
    char stringdata8[11];
    char stringdata9[20];
    char stringdata10[16];
    char stringdata11[23];
    char stringdata12[2];
    char stringdata13[21];
    char stringdata14[11];
    char stringdata15[12];
    char stringdata16[11];
    char stringdata17[20];
    char stringdata18[17];
    char stringdata19[17];
    char stringdata20[16];
    char stringdata21[10];
    char stringdata22[19];
    char stringdata23[19];
    char stringdata24[11];
    char stringdata25[11];
    char stringdata26[10];
    char stringdata27[18];
    char stringdata28[14];
    char stringdata29[14];
    char stringdata30[15];
    char stringdata31[15];
    char stringdata32[15];
    char stringdata33[12];
    char stringdata34[14];
    char stringdata35[15];
    char stringdata36[13];
    char stringdata37[9];
    char stringdata38[12];
    char stringdata39[8];
    char stringdata40[9];
    char stringdata41[5];
    char stringdata42[7];
    char stringdata43[3];
    char stringdata44[18];
    char stringdata45[2];
    char stringdata46[10];
    char stringdata47[6];
    char stringdata48[10];
    char stringdata49[6];
    char stringdata50[16];
    char stringdata51[6];
    char stringdata52[18];
    char stringdata53[8];
    char stringdata54[13];
    char stringdata55[4];
    char stringdata56[14];
    char stringdata57[4];
    char stringdata58[13];
    char stringdata59[4];
    char stringdata60[16];
    char stringdata61[5];
    char stringdata62[9];
    char stringdata63[5];
    char stringdata64[8];
    char stringdata65[4];
    char stringdata66[9];
    char stringdata67[5];
    char stringdata68[10];
    char stringdata69[6];
    char stringdata70[16];
    char stringdata71[8];
    char stringdata72[11];
    char stringdata73[3];
    char stringdata74[11];
    char stringdata75[7];
    char stringdata76[13];
    char stringdata77[9];
    char stringdata78[17];
    char stringdata79[2];
    char stringdata80[16];
    char stringdata81[2];
    char stringdata82[11];
    char stringdata83[7];
    char stringdata84[11];
    char stringdata85[7];
    char stringdata86[10];
    char stringdata87[6];
    char stringdata88[10];
    char stringdata89[6];
    char stringdata90[11];
    char stringdata91[7];
    char stringdata92[14];
    char stringdata93[13];
    char stringdata94[2];
    char stringdata95[12];
    char stringdata96[9];
    char stringdata97[5];
    char stringdata98[12];
    char stringdata99[8];
    char stringdata100[10];
    char stringdata101[6];
    char stringdata102[13];
    char stringdata103[9];
    char stringdata104[12];
    char stringdata105[8];
    char stringdata106[9];
    char stringdata107[5];
    char stringdata108[9];
    char stringdata109[5];
    char stringdata110[8];
    char stringdata111[4];
    char stringdata112[17];
    char stringdata113[6];
    char stringdata114[12];
    char stringdata115[5];
    char stringdata116[8];
    char stringdata117[4];
    char stringdata118[10];
    char stringdata119[6];
    char stringdata120[16];
    char stringdata121[2];
    char stringdata122[16];
    char stringdata123[18];
    char stringdata124[18];
    char stringdata125[20];
    char stringdata126[20];
    char stringdata127[17];
    char stringdata128[17];
    char stringdata129[17];
    char stringdata130[17];
    char stringdata131[21];
    char stringdata132[22];
    char stringdata133[20];
    char stringdata134[20];
    char stringdata135[20];
    char stringdata136[21];
    char stringdata137[14];
    char stringdata138[16];
    char stringdata139[2];
    char stringdata140[16];
    char stringdata141[9];
    char stringdata142[11];
    char stringdata143[9];
    char stringdata144[17];
    char stringdata145[17];
    char stringdata146[18];
    char stringdata147[20];
    char stringdata148[15];
    char stringdata149[16];
    char stringdata150[20];
    char stringdata151[20];
    char stringdata152[2];
    char stringdata153[18];
    char stringdata154[16];
    char stringdata155[11];
    char stringdata156[11];
    char stringdata157[11];
    char stringdata158[11];
    char stringdata159[11];
    char stringdata160[11];
    char stringdata161[10];
    char stringdata162[10];
    char stringdata163[10];
    char stringdata164[10];
    char stringdata165[10];
    char stringdata166[10];
    char stringdata167[18];
    char stringdata168[19];
    char stringdata169[17];
    char stringdata170[9];
    char stringdata171[9];
    char stringdata172[11];
    char stringdata173[13];
    char stringdata174[10];
    char stringdata175[10];
    char stringdata176[16];
    char stringdata177[18];
    char stringdata178[13];
    char stringdata179[14];
    char stringdata180[13];
    char stringdata181[16];
    char stringdata182[9];
    char stringdata183[8];
    char stringdata184[9];
    char stringdata185[10];
    char stringdata186[16];
    char stringdata187[12];
    char stringdata188[10];
    char stringdata189[13];
    char stringdata190[13];
    char stringdata191[13];
    char stringdata192[13];
    char stringdata193[13];
    char stringdata194[13];
    char stringdata195[13];
    char stringdata196[14];
    char stringdata197[13];
    char stringdata198[13];
    char stringdata199[11];
    char stringdata200[11];
    char stringdata201[10];
    char stringdata202[10];
    char stringdata203[14];
    char stringdata204[15];
    char stringdata205[13];
    char stringdata206[9];
    char stringdata207[12];
    char stringdata208[16];
    char stringdata209[13];
    char stringdata210[11];
    char stringdata211[14];
    char stringdata212[13];
    char stringdata213[16];
    char stringdata214[16];
    char stringdata215[18];
    char stringdata216[18];
    char stringdata217[20];
    char stringdata218[20];
    char stringdata219[17];
    char stringdata220[17];
    char stringdata221[17];
    char stringdata222[17];
    char stringdata223[21];
    char stringdata224[22];
    char stringdata225[20];
    char stringdata226[20];
    char stringdata227[20];
    char stringdata228[21];
    char stringdata229[14];
    char stringdata230[16];
    char stringdata231[13];
    char stringdata232[21];
    char stringdata233[13];
    char stringdata234[9];
    char stringdata235[14];
    char stringdata236[19];
    char stringdata237[14];
    char stringdata238[2];
    char stringdata239[16];
    char stringdata240[15];
    char stringdata241[17];
    char stringdata242[17];
    char stringdata243[2];
    char stringdata244[12];
    char stringdata245[17];
    char stringdata246[17];
    char stringdata247[20];
    char stringdata248[18];
    char stringdata249[18];
    char stringdata250[18];
    char stringdata251[18];
    char stringdata252[19];
    char stringdata253[18];
    char stringdata254[18];
    char stringdata255[16];
    char stringdata256[17];
    char stringdata257[15];
    char stringdata258[10];
    char stringdata259[14];
    char stringdata260[20];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_DroidStar_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_DroidStar_t qt_meta_stringdata_DroidStar = {
    {
        QT_MOC_LITERAL(0, 9),  // "DroidStar"
        QT_MOC_LITERAL(10, 20),  // "input_source_changed"
        QT_MOC_LITERAL(31, 0),  // ""
        QT_MOC_LITERAL(32, 12),  // "mode_changed"
        QT_MOC_LITERAL(45, 14),  // "module_changed"
        QT_MOC_LITERAL(60, 12),  // "slot_changed"
        QT_MOC_LITERAL(73, 10),  // "cc_changed"
        QT_MOC_LITERAL(84, 11),  // "update_data"
        QT_MOC_LITERAL(96, 10),  // "update_log"
        QT_MOC_LITERAL(107, 19),  // "open_vocoder_dialog"
        QT_MOC_LITERAL(127, 15),  // "update_settings"
        QT_MOC_LITERAL(143, 22),  // "connect_status_changed"
        QT_MOC_LITERAL(166, 1),  // "c"
        QT_MOC_LITERAL(168, 20),  // "in_audio_vol_changed"
        QT_MOC_LITERAL(189, 10),  // "tx_pressed"
        QT_MOC_LITERAL(200, 11),  // "tx_released"
        QT_MOC_LITERAL(212, 10),  // "tx_clicked"
        QT_MOC_LITERAL(223, 19),  // "dmrpc_state_changed"
        QT_MOC_LITERAL(243, 16),  // "dmr_tgid_changed"
        QT_MOC_LITERAL(260, 16),  // "m17_rate_changed"
        QT_MOC_LITERAL(277, 15),  // "m17_can_changed"
        QT_MOC_LITERAL(293, 9),  // "send_dtmf"
        QT_MOC_LITERAL(303, 18),  // "swtx_state_changed"
        QT_MOC_LITERAL(322, 18),  // "swrx_state_changed"
        QT_MOC_LITERAL(341, 10),  // "swtx_state"
        QT_MOC_LITERAL(352, 10),  // "swrx_state"
        QT_MOC_LITERAL(363, 9),  // "agc_state"
        QT_MOC_LITERAL(373, 17),  // "agc_state_changed"
        QT_MOC_LITERAL(391, 13),  // "rptr1_changed"
        QT_MOC_LITERAL(405, 13),  // "rptr2_changed"
        QT_MOC_LITERAL(419, 14),  // "mycall_changed"
        QT_MOC_LITERAL(434, 14),  // "urcall_changed"
        QT_MOC_LITERAL(449, 14),  // "usrtxt_changed"
        QT_MOC_LITERAL(464, 11),  // "dst_changed"
        QT_MOC_LITERAL(476, 13),  // "debug_changed"
        QT_MOC_LITERAL(490, 14),  // "update_devices"
        QT_MOC_LITERAL(505, 12),  // "set_callsign"
        QT_MOC_LITERAL(518, 8),  // "callsign"
        QT_MOC_LITERAL(527, 11),  // "set_dmrtgid"
        QT_MOC_LITERAL(539, 7),  // "dmrtgid"
        QT_MOC_LITERAL(547, 8),  // "set_slot"
        QT_MOC_LITERAL(556, 4),  // "slot"
        QT_MOC_LITERAL(561, 6),  // "set_cc"
        QT_MOC_LITERAL(568, 2),  // "cc"
        QT_MOC_LITERAL(571, 17),  // "tgid_text_changed"
        QT_MOC_LITERAL(589, 1),  // "s"
        QT_MOC_LITERAL(591, 9),  // "set_dmrid"
        QT_MOC_LITERAL(601, 5),  // "dmrid"
        QT_MOC_LITERAL(607, 9),  // "set_essid"
        QT_MOC_LITERAL(617, 5),  // "essid"
        QT_MOC_LITERAL(623, 15),  // "set_bm_password"
        QT_MOC_LITERAL(639, 5),  // "bmpwd"
        QT_MOC_LITERAL(645, 17),  // "set_tgif_password"
        QT_MOC_LITERAL(663, 7),  // "tgifpwd"
        QT_MOC_LITERAL(671, 12),  // "set_latitude"
        QT_MOC_LITERAL(684, 3),  // "lat"
        QT_MOC_LITERAL(688, 13),  // "set_longitude"
        QT_MOC_LITERAL(702, 3),  // "lon"
        QT_MOC_LITERAL(706, 12),  // "set_location"
        QT_MOC_LITERAL(719, 3),  // "loc"
        QT_MOC_LITERAL(723, 15),  // "set_description"
        QT_MOC_LITERAL(739, 4),  // "desc"
        QT_MOC_LITERAL(744, 8),  // "set_freq"
        QT_MOC_LITERAL(753, 4),  // "freq"
        QT_MOC_LITERAL(758, 7),  // "set_url"
        QT_MOC_LITERAL(766, 3),  // "url"
        QT_MOC_LITERAL(770, 8),  // "set_swid"
        QT_MOC_LITERAL(779, 4),  // "swid"
        QT_MOC_LITERAL(784, 9),  // "set_pkgid"
        QT_MOC_LITERAL(794, 5),  // "pkgid"
        QT_MOC_LITERAL(800, 15),  // "set_dmr_options"
        QT_MOC_LITERAL(816, 7),  // "dmropts"
        QT_MOC_LITERAL(824, 10),  // "set_dmr_pc"
        QT_MOC_LITERAL(835, 2),  // "pc"
        QT_MOC_LITERAL(838, 10),  // "set_module"
        QT_MOC_LITERAL(849, 6),  // "module"
        QT_MOC_LITERAL(856, 12),  // "set_protocol"
        QT_MOC_LITERAL(869, 8),  // "protocol"
        QT_MOC_LITERAL(878, 16),  // "set_input_volume"
        QT_MOC_LITERAL(895, 1),  // "v"
        QT_MOC_LITERAL(897, 15),  // "set_modelchange"
        QT_MOC_LITERAL(913, 1),  // "t"
        QT_MOC_LITERAL(915, 10),  // "set_mycall"
        QT_MOC_LITERAL(926, 6),  // "mycall"
        QT_MOC_LITERAL(933, 10),  // "set_urcall"
        QT_MOC_LITERAL(944, 6),  // "urcall"
        QT_MOC_LITERAL(951, 9),  // "set_rptr1"
        QT_MOC_LITERAL(961, 5),  // "rptr1"
        QT_MOC_LITERAL(967, 9),  // "set_rptr2"
        QT_MOC_LITERAL(977, 5),  // "rptr2"
        QT_MOC_LITERAL(983, 10),  // "set_usrtxt"
        QT_MOC_LITERAL(994, 6),  // "usrtxt"
        QT_MOC_LITERAL(1001, 13),  // "set_txtimeout"
        QT_MOC_LITERAL(1015, 12),  // "set_toggletx"
        QT_MOC_LITERAL(1028, 1),  // "x"
        QT_MOC_LITERAL(1030, 11),  // "set_xrf2ref"
        QT_MOC_LITERAL(1042, 8),  // "set_ipv6"
        QT_MOC_LITERAL(1051, 4),  // "ipv6"
        QT_MOC_LITERAL(1056, 11),  // "set_vocoder"
        QT_MOC_LITERAL(1068, 7),  // "vocoder"
        QT_MOC_LITERAL(1076, 9),  // "set_modem"
        QT_MOC_LITERAL(1086, 5),  // "modem"
        QT_MOC_LITERAL(1092, 12),  // "set_playback"
        QT_MOC_LITERAL(1105, 8),  // "playback"
        QT_MOC_LITERAL(1114, 11),  // "set_capture"
        QT_MOC_LITERAL(1126, 7),  // "capture"
        QT_MOC_LITERAL(1134, 8),  // "set_swtx"
        QT_MOC_LITERAL(1143, 4),  // "swtx"
        QT_MOC_LITERAL(1148, 8),  // "set_swrx"
        QT_MOC_LITERAL(1157, 4),  // "swrx"
        QT_MOC_LITERAL(1162, 7),  // "set_agc"
        QT_MOC_LITERAL(1170, 3),  // "agc"
        QT_MOC_LITERAL(1174, 16),  // "set_mmdvm_direct"
        QT_MOC_LITERAL(1191, 5),  // "mmdvm"
        QT_MOC_LITERAL(1197, 11),  // "set_iaxport"
        QT_MOC_LITERAL(1209, 4),  // "port"
        QT_MOC_LITERAL(1214, 7),  // "set_dst"
        QT_MOC_LITERAL(1222, 3),  // "dst"
        QT_MOC_LITERAL(1226, 9),  // "set_debug"
        QT_MOC_LITERAL(1236, 5),  // "debug"
        QT_MOC_LITERAL(1242, 15),  // "set_modemRxFreq"
        QT_MOC_LITERAL(1258, 1),  // "m"
        QT_MOC_LITERAL(1260, 15),  // "set_modemTxFreq"
        QT_MOC_LITERAL(1276, 17),  // "set_modemRxOffset"
        QT_MOC_LITERAL(1294, 17),  // "set_modemTxOffset"
        QT_MOC_LITERAL(1312, 19),  // "set_modemRxDCOffset"
        QT_MOC_LITERAL(1332, 19),  // "set_modemTxDCOffset"
        QT_MOC_LITERAL(1352, 16),  // "set_modemRxLevel"
        QT_MOC_LITERAL(1369, 16),  // "set_modemTxLevel"
        QT_MOC_LITERAL(1386, 16),  // "set_modemRFLevel"
        QT_MOC_LITERAL(1403, 16),  // "set_modemTxDelay"
        QT_MOC_LITERAL(1420, 20),  // "set_modemCWIdTxLevel"
        QT_MOC_LITERAL(1441, 21),  // "set_modemDstarTxLevel"
        QT_MOC_LITERAL(1463, 19),  // "set_modemDMRTxLevel"
        QT_MOC_LITERAL(1483, 19),  // "set_modemYSFTxLevel"
        QT_MOC_LITERAL(1503, 19),  // "set_modemP25TxLevel"
        QT_MOC_LITERAL(1523, 20),  // "set_modemNXDNTxLevel"
        QT_MOC_LITERAL(1544, 13),  // "set_modemBaud"
        QT_MOC_LITERAL(1558, 15),  // "set_modemM17CAN"
        QT_MOC_LITERAL(1574, 1),  // "r"
        QT_MOC_LITERAL(1576, 15),  // "process_connect"
        QT_MOC_LITERAL(1592, 8),  // "press_tx"
        QT_MOC_LITERAL(1601, 10),  // "release_tx"
        QT_MOC_LITERAL(1612, 8),  // "click_tx"
        QT_MOC_LITERAL(1621, 16),  // "process_settings"
        QT_MOC_LITERAL(1638, 16),  // "check_host_files"
        QT_MOC_LITERAL(1655, 17),  // "update_host_files"
        QT_MOC_LITERAL(1673, 19),  // "update_custom_hosts"
        QT_MOC_LITERAL(1693, 14),  // "update_dmr_ids"
        QT_MOC_LITERAL(1708, 15),  // "update_nxdn_ids"
        QT_MOC_LITERAL(1724, 19),  // "process_mode_change"
        QT_MOC_LITERAL(1744, 19),  // "process_host_change"
        QT_MOC_LITERAL(1764, 1),  // "h"
        QT_MOC_LITERAL(1766, 17),  // "dtmf_send_clicked"
        QT_MOC_LITERAL(1784, 15),  // "get_modelchange"
        QT_MOC_LITERAL(1800, 10),  // "get_label1"
        QT_MOC_LITERAL(1811, 10),  // "get_label2"
        QT_MOC_LITERAL(1822, 10),  // "get_label3"
        QT_MOC_LITERAL(1833, 10),  // "get_label4"
        QT_MOC_LITERAL(1844, 10),  // "get_label5"
        QT_MOC_LITERAL(1855, 10),  // "get_label6"
        QT_MOC_LITERAL(1866, 9),  // "get_data1"
        QT_MOC_LITERAL(1876, 9),  // "get_data2"
        QT_MOC_LITERAL(1886, 9),  // "get_data3"
        QT_MOC_LITERAL(1896, 9),  // "get_data4"
        QT_MOC_LITERAL(1906, 9),  // "get_data5"
        QT_MOC_LITERAL(1916, 9),  // "get_data6"
        QT_MOC_LITERAL(1926, 17),  // "get_ambestatustxt"
        QT_MOC_LITERAL(1944, 18),  // "get_mmdvmstatustxt"
        QT_MOC_LITERAL(1963, 16),  // "get_netstatustxt"
        QT_MOC_LITERAL(1980, 8),  // "get_mode"
        QT_MOC_LITERAL(1989, 8),  // "get_host"
        QT_MOC_LITERAL(1998, 10),  // "get_module"
        QT_MOC_LITERAL(2009, 12),  // "get_callsign"
        QT_MOC_LITERAL(2022, 9),  // "get_dmrid"
        QT_MOC_LITERAL(2032, 9),  // "get_essid"
        QT_MOC_LITERAL(2042, 15),  // "get_bm_password"
        QT_MOC_LITERAL(2058, 17),  // "get_tgif_password"
        QT_MOC_LITERAL(2076, 12),  // "get_latitude"
        QT_MOC_LITERAL(2089, 13),  // "get_longitude"
        QT_MOC_LITERAL(2103, 12),  // "get_location"
        QT_MOC_LITERAL(2116, 15),  // "get_description"
        QT_MOC_LITERAL(2132, 8),  // "get_freq"
        QT_MOC_LITERAL(2141, 7),  // "get_url"
        QT_MOC_LITERAL(2149, 8),  // "get_swid"
        QT_MOC_LITERAL(2158, 9),  // "get_pkgid"
        QT_MOC_LITERAL(2168, 15),  // "get_dmr_options"
        QT_MOC_LITERAL(2184, 11),  // "get_dmrtgid"
        QT_MOC_LITERAL(2196, 9),  // "get_hosts"
        QT_MOC_LITERAL(2206, 12),  // "get_ref_host"
        QT_MOC_LITERAL(2219, 12),  // "get_dcs_host"
        QT_MOC_LITERAL(2232, 12),  // "get_xrf_host"
        QT_MOC_LITERAL(2245, 12),  // "get_ysf_host"
        QT_MOC_LITERAL(2258, 12),  // "get_fcs_host"
        QT_MOC_LITERAL(2271, 12),  // "get_dmr_host"
        QT_MOC_LITERAL(2284, 12),  // "get_p25_host"
        QT_MOC_LITERAL(2297, 13),  // "get_nxdn_host"
        QT_MOC_LITERAL(2311, 12),  // "get_m17_host"
        QT_MOC_LITERAL(2324, 12),  // "get_iax_host"
        QT_MOC_LITERAL(2337, 10),  // "get_mycall"
        QT_MOC_LITERAL(2348, 10),  // "get_urcall"
        QT_MOC_LITERAL(2359, 9),  // "get_rptr1"
        QT_MOC_LITERAL(2369, 9),  // "get_rptr2"
        QT_MOC_LITERAL(2379, 13),  // "get_txtimeout"
        QT_MOC_LITERAL(2393, 14),  // "get_error_text"
        QT_MOC_LITERAL(2408, 12),  // "get_toggletx"
        QT_MOC_LITERAL(2421, 8),  // "get_ipv6"
        QT_MOC_LITERAL(2430, 11),  // "get_xrf2ref"
        QT_MOC_LITERAL(2442, 15),  // "get_local_hosts"
        QT_MOC_LITERAL(2458, 12),  // "get_vocoders"
        QT_MOC_LITERAL(2471, 10),  // "get_modems"
        QT_MOC_LITERAL(2482, 13),  // "get_playbacks"
        QT_MOC_LITERAL(2496, 12),  // "get_captures"
        QT_MOC_LITERAL(2509, 15),  // "get_modemRxFreq"
        QT_MOC_LITERAL(2525, 15),  // "get_modemTxFreq"
        QT_MOC_LITERAL(2541, 17),  // "get_modemRxOffset"
        QT_MOC_LITERAL(2559, 17),  // "get_modemTxOffset"
        QT_MOC_LITERAL(2577, 19),  // "get_modemRxDCOffset"
        QT_MOC_LITERAL(2597, 19),  // "get_modemTxDCOffset"
        QT_MOC_LITERAL(2617, 16),  // "get_modemRxLevel"
        QT_MOC_LITERAL(2634, 16),  // "get_modemTxLevel"
        QT_MOC_LITERAL(2651, 16),  // "get_modemRFLevel"
        QT_MOC_LITERAL(2668, 16),  // "get_modemTxDelay"
        QT_MOC_LITERAL(2685, 20),  // "get_modemCWIdTxLevel"
        QT_MOC_LITERAL(2706, 21),  // "get_modemDstarTxLevel"
        QT_MOC_LITERAL(2728, 19),  // "get_modemDMRTxLevel"
        QT_MOC_LITERAL(2748, 19),  // "get_modemYSFTxLevel"
        QT_MOC_LITERAL(2768, 19),  // "get_modemP25TxLevel"
        QT_MOC_LITERAL(2788, 20),  // "get_modemNXDNTxLevel"
        QT_MOC_LITERAL(2809, 13),  // "get_modemBaud"
        QT_MOC_LITERAL(2823, 15),  // "get_modemM17CAN"
        QT_MOC_LITERAL(2839, 12),  // "get_platform"
        QT_MOC_LITERAL(2852, 20),  // "reset_connect_status"
        QT_MOC_LITERAL(2873, 12),  // "get_monofont"
        QT_MOC_LITERAL(2886, 8),  // "get_arch"
        QT_MOC_LITERAL(2895, 13),  // "get_build_abi"
        QT_MOC_LITERAL(2909, 18),  // "get_software_build"
        QT_MOC_LITERAL(2928, 13),  // "download_file"
        QT_MOC_LITERAL(2942, 1),  // "u"
        QT_MOC_LITERAL(2944, 15),  // "file_downloaded"
        QT_MOC_LITERAL(2960, 14),  // "url_downloaded"
        QT_MOC_LITERAL(2975, 16),  // "get_output_level"
        QT_MOC_LITERAL(2992, 16),  // "set_output_level"
        QT_MOC_LITERAL(3009, 1),  // "l"
        QT_MOC_LITERAL(3011, 11),  // "tts_changed"
        QT_MOC_LITERAL(3023, 16),  // "tts_text_changed"
        QT_MOC_LITERAL(3040, 16),  // "discover_devices"
        QT_MOC_LITERAL(3057, 19),  // "process_dstar_hosts"
        QT_MOC_LITERAL(3077, 17),  // "process_ysf_hosts"
        QT_MOC_LITERAL(3095, 17),  // "process_fcs_rooms"
        QT_MOC_LITERAL(3113, 17),  // "process_dmr_hosts"
        QT_MOC_LITERAL(3131, 17),  // "process_p25_hosts"
        QT_MOC_LITERAL(3149, 18),  // "process_nxdn_hosts"
        QT_MOC_LITERAL(3168, 17),  // "process_m17_hosts"
        QT_MOC_LITERAL(3186, 17),  // "process_iax_hosts"
        QT_MOC_LITERAL(3204, 15),  // "process_dmr_ids"
        QT_MOC_LITERAL(3220, 16),  // "process_nxdn_ids"
        QT_MOC_LITERAL(3237, 14),  // "Mode::MODEINFO"
        QT_MOC_LITERAL(3252, 9),  // "updatelog"
        QT_MOC_LITERAL(3262, 13),  // "save_settings"
        QT_MOC_LITERAL(3276, 19)   // "update_output_level"
    },
    "DroidStar",
    "input_source_changed",
    "",
    "mode_changed",
    "module_changed",
    "slot_changed",
    "cc_changed",
    "update_data",
    "update_log",
    "open_vocoder_dialog",
    "update_settings",
    "connect_status_changed",
    "c",
    "in_audio_vol_changed",
    "tx_pressed",
    "tx_released",
    "tx_clicked",
    "dmrpc_state_changed",
    "dmr_tgid_changed",
    "m17_rate_changed",
    "m17_can_changed",
    "send_dtmf",
    "swtx_state_changed",
    "swrx_state_changed",
    "swtx_state",
    "swrx_state",
    "agc_state",
    "agc_state_changed",
    "rptr1_changed",
    "rptr2_changed",
    "mycall_changed",
    "urcall_changed",
    "usrtxt_changed",
    "dst_changed",
    "debug_changed",
    "update_devices",
    "set_callsign",
    "callsign",
    "set_dmrtgid",
    "dmrtgid",
    "set_slot",
    "slot",
    "set_cc",
    "cc",
    "tgid_text_changed",
    "s",
    "set_dmrid",
    "dmrid",
    "set_essid",
    "essid",
    "set_bm_password",
    "bmpwd",
    "set_tgif_password",
    "tgifpwd",
    "set_latitude",
    "lat",
    "set_longitude",
    "lon",
    "set_location",
    "loc",
    "set_description",
    "desc",
    "set_freq",
    "freq",
    "set_url",
    "url",
    "set_swid",
    "swid",
    "set_pkgid",
    "pkgid",
    "set_dmr_options",
    "dmropts",
    "set_dmr_pc",
    "pc",
    "set_module",
    "module",
    "set_protocol",
    "protocol",
    "set_input_volume",
    "v",
    "set_modelchange",
    "t",
    "set_mycall",
    "mycall",
    "set_urcall",
    "urcall",
    "set_rptr1",
    "rptr1",
    "set_rptr2",
    "rptr2",
    "set_usrtxt",
    "usrtxt",
    "set_txtimeout",
    "set_toggletx",
    "x",
    "set_xrf2ref",
    "set_ipv6",
    "ipv6",
    "set_vocoder",
    "vocoder",
    "set_modem",
    "modem",
    "set_playback",
    "playback",
    "set_capture",
    "capture",
    "set_swtx",
    "swtx",
    "set_swrx",
    "swrx",
    "set_agc",
    "agc",
    "set_mmdvm_direct",
    "mmdvm",
    "set_iaxport",
    "port",
    "set_dst",
    "dst",
    "set_debug",
    "debug",
    "set_modemRxFreq",
    "m",
    "set_modemTxFreq",
    "set_modemRxOffset",
    "set_modemTxOffset",
    "set_modemRxDCOffset",
    "set_modemTxDCOffset",
    "set_modemRxLevel",
    "set_modemTxLevel",
    "set_modemRFLevel",
    "set_modemTxDelay",
    "set_modemCWIdTxLevel",
    "set_modemDstarTxLevel",
    "set_modemDMRTxLevel",
    "set_modemYSFTxLevel",
    "set_modemP25TxLevel",
    "set_modemNXDNTxLevel",
    "set_modemBaud",
    "set_modemM17CAN",
    "r",
    "process_connect",
    "press_tx",
    "release_tx",
    "click_tx",
    "process_settings",
    "check_host_files",
    "update_host_files",
    "update_custom_hosts",
    "update_dmr_ids",
    "update_nxdn_ids",
    "process_mode_change",
    "process_host_change",
    "h",
    "dtmf_send_clicked",
    "get_modelchange",
    "get_label1",
    "get_label2",
    "get_label3",
    "get_label4",
    "get_label5",
    "get_label6",
    "get_data1",
    "get_data2",
    "get_data3",
    "get_data4",
    "get_data5",
    "get_data6",
    "get_ambestatustxt",
    "get_mmdvmstatustxt",
    "get_netstatustxt",
    "get_mode",
    "get_host",
    "get_module",
    "get_callsign",
    "get_dmrid",
    "get_essid",
    "get_bm_password",
    "get_tgif_password",
    "get_latitude",
    "get_longitude",
    "get_location",
    "get_description",
    "get_freq",
    "get_url",
    "get_swid",
    "get_pkgid",
    "get_dmr_options",
    "get_dmrtgid",
    "get_hosts",
    "get_ref_host",
    "get_dcs_host",
    "get_xrf_host",
    "get_ysf_host",
    "get_fcs_host",
    "get_dmr_host",
    "get_p25_host",
    "get_nxdn_host",
    "get_m17_host",
    "get_iax_host",
    "get_mycall",
    "get_urcall",
    "get_rptr1",
    "get_rptr2",
    "get_txtimeout",
    "get_error_text",
    "get_toggletx",
    "get_ipv6",
    "get_xrf2ref",
    "get_local_hosts",
    "get_vocoders",
    "get_modems",
    "get_playbacks",
    "get_captures",
    "get_modemRxFreq",
    "get_modemTxFreq",
    "get_modemRxOffset",
    "get_modemTxOffset",
    "get_modemRxDCOffset",
    "get_modemTxDCOffset",
    "get_modemRxLevel",
    "get_modemTxLevel",
    "get_modemRFLevel",
    "get_modemTxDelay",
    "get_modemCWIdTxLevel",
    "get_modemDstarTxLevel",
    "get_modemDMRTxLevel",
    "get_modemYSFTxLevel",
    "get_modemP25TxLevel",
    "get_modemNXDNTxLevel",
    "get_modemBaud",
    "get_modemM17CAN",
    "get_platform",
    "reset_connect_status",
    "get_monofont",
    "get_arch",
    "get_build_abi",
    "get_software_build",
    "download_file",
    "u",
    "file_downloaded",
    "url_downloaded",
    "get_output_level",
    "set_output_level",
    "l",
    "tts_changed",
    "tts_text_changed",
    "discover_devices",
    "process_dstar_hosts",
    "process_ysf_hosts",
    "process_fcs_rooms",
    "process_dmr_hosts",
    "process_p25_hosts",
    "process_nxdn_hosts",
    "process_m17_hosts",
    "process_iax_hosts",
    "process_dmr_ids",
    "process_nxdn_ids",
    "Mode::MODEINFO",
    "updatelog",
    "save_settings",
    "update_output_level"
};
#undef QT_MOC_LITERAL
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_DroidStar[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
     214,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      33,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    2, 1298,    2, 0x06,    1 /* Public */,
       3,    0, 1303,    2, 0x06,    4 /* Public */,
       4,    1, 1304,    2, 0x06,    5 /* Public */,
       5,    1, 1307,    2, 0x06,    7 /* Public */,
       6,    1, 1310,    2, 0x06,    9 /* Public */,
       7,    0, 1313,    2, 0x06,   11 /* Public */,
       8,    1, 1314,    2, 0x06,   12 /* Public */,
       9,    0, 1317,    2, 0x06,   14 /* Public */,
      10,    0, 1318,    2, 0x06,   15 /* Public */,
      11,    1, 1319,    2, 0x06,   16 /* Public */,
      13,    1, 1322,    2, 0x06,   18 /* Public */,
      14,    0, 1325,    2, 0x06,   20 /* Public */,
      15,    0, 1326,    2, 0x06,   21 /* Public */,
      16,    1, 1327,    2, 0x06,   22 /* Public */,
      17,    1, 1330,    2, 0x06,   24 /* Public */,
      18,    1, 1333,    2, 0x06,   26 /* Public */,
      19,    1, 1336,    2, 0x06,   28 /* Public */,
      20,    1, 1339,    2, 0x06,   30 /* Public */,
      21,    1, 1342,    2, 0x06,   32 /* Public */,
      22,    1, 1345,    2, 0x06,   34 /* Public */,
      23,    1, 1348,    2, 0x06,   36 /* Public */,
      24,    1, 1351,    2, 0x06,   38 /* Public */,
      25,    1, 1354,    2, 0x06,   40 /* Public */,
      26,    1, 1357,    2, 0x06,   42 /* Public */,
      27,    1, 1360,    2, 0x06,   44 /* Public */,
      28,    1, 1363,    2, 0x06,   46 /* Public */,
      29,    1, 1366,    2, 0x06,   48 /* Public */,
      30,    1, 1369,    2, 0x06,   50 /* Public */,
      31,    1, 1372,    2, 0x06,   52 /* Public */,
      32,    1, 1375,    2, 0x06,   54 /* Public */,
      33,    1, 1378,    2, 0x06,   56 /* Public */,
      34,    1, 1381,    2, 0x06,   58 /* Public */,
      35,    0, 1384,    2, 0x06,   60 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
      36,    1, 1385,    2, 0x0a,   61 /* Public */,
      38,    1, 1388,    2, 0x0a,   63 /* Public */,
      40,    1, 1391,    2, 0x0a,   65 /* Public */,
      42,    1, 1394,    2, 0x0a,   67 /* Public */,
      44,    1, 1397,    2, 0x0a,   69 /* Public */,
      46,    1, 1400,    2, 0x0a,   71 /* Public */,
      48,    1, 1403,    2, 0x0a,   73 /* Public */,
      50,    1, 1406,    2, 0x0a,   75 /* Public */,
      52,    1, 1409,    2, 0x0a,   77 /* Public */,
      54,    1, 1412,    2, 0x0a,   79 /* Public */,
      56,    1, 1415,    2, 0x0a,   81 /* Public */,
      58,    1, 1418,    2, 0x0a,   83 /* Public */,
      60,    1, 1421,    2, 0x0a,   85 /* Public */,
      62,    1, 1424,    2, 0x0a,   87 /* Public */,
      64,    1, 1427,    2, 0x0a,   89 /* Public */,
      66,    1, 1430,    2, 0x0a,   91 /* Public */,
      68,    1, 1433,    2, 0x0a,   93 /* Public */,
      70,    1, 1436,    2, 0x0a,   95 /* Public */,
      72,    1, 1439,    2, 0x0a,   97 /* Public */,
      74,    1, 1442,    2, 0x0a,   99 /* Public */,
      76,    1, 1445,    2, 0x0a,  101 /* Public */,
      78,    1, 1448,    2, 0x0a,  103 /* Public */,
      80,    1, 1451,    2, 0x0a,  105 /* Public */,
      82,    1, 1454,    2, 0x0a,  107 /* Public */,
      84,    1, 1457,    2, 0x0a,  109 /* Public */,
      86,    1, 1460,    2, 0x0a,  111 /* Public */,
      88,    1, 1463,    2, 0x0a,  113 /* Public */,
      90,    1, 1466,    2, 0x0a,  115 /* Public */,
      92,    1, 1469,    2, 0x0a,  117 /* Public */,
      93,    1, 1472,    2, 0x0a,  119 /* Public */,
      95,    1, 1475,    2, 0x0a,  121 /* Public */,
      96,    1, 1478,    2, 0x0a,  123 /* Public */,
      98,    1, 1481,    2, 0x0a,  125 /* Public */,
     100,    1, 1484,    2, 0x0a,  127 /* Public */,
     102,    1, 1487,    2, 0x0a,  129 /* Public */,
     104,    1, 1490,    2, 0x0a,  131 /* Public */,
     106,    1, 1493,    2, 0x0a,  133 /* Public */,
     108,    1, 1496,    2, 0x0a,  135 /* Public */,
     110,    1, 1499,    2, 0x0a,  137 /* Public */,
     112,    1, 1502,    2, 0x0a,  139 /* Public */,
     114,    1, 1505,    2, 0x0a,  141 /* Public */,
     116,    1, 1508,    2, 0x0a,  143 /* Public */,
     118,    1, 1511,    2, 0x0a,  145 /* Public */,
     120,    1, 1514,    2, 0x0a,  147 /* Public */,
     122,    1, 1517,    2, 0x0a,  149 /* Public */,
     123,    1, 1520,    2, 0x0a,  151 /* Public */,
     124,    1, 1523,    2, 0x0a,  153 /* Public */,
     125,    1, 1526,    2, 0x0a,  155 /* Public */,
     126,    1, 1529,    2, 0x0a,  157 /* Public */,
     127,    1, 1532,    2, 0x0a,  159 /* Public */,
     128,    1, 1535,    2, 0x0a,  161 /* Public */,
     129,    1, 1538,    2, 0x0a,  163 /* Public */,
     130,    1, 1541,    2, 0x0a,  165 /* Public */,
     131,    1, 1544,    2, 0x0a,  167 /* Public */,
     132,    1, 1547,    2, 0x0a,  169 /* Public */,
     133,    1, 1550,    2, 0x0a,  171 /* Public */,
     134,    1, 1553,    2, 0x0a,  173 /* Public */,
     135,    1, 1556,    2, 0x0a,  175 /* Public */,
     136,    1, 1559,    2, 0x0a,  177 /* Public */,
     137,    1, 1562,    2, 0x0a,  179 /* Public */,
     138,    1, 1565,    2, 0x0a,  181 /* Public */,
      19,    1, 1568,    2, 0x0a,  183 /* Public */,
     140,    0, 1571,    2, 0x0a,  185 /* Public */,
     141,    0, 1572,    2, 0x0a,  186 /* Public */,
     142,    0, 1573,    2, 0x0a,  187 /* Public */,
     143,    1, 1574,    2, 0x0a,  188 /* Public */,
     144,    0, 1577,    2, 0x0a,  190 /* Public */,
     145,    0, 1578,    2, 0x0a,  191 /* Public */,
     146,    0, 1579,    2, 0x0a,  192 /* Public */,
     147,    1, 1580,    2, 0x0a,  193 /* Public */,
     148,    0, 1583,    2, 0x0a,  195 /* Public */,
     149,    0, 1584,    2, 0x0a,  196 /* Public */,
     150,    1, 1585,    2, 0x0a,  197 /* Public */,
     151,    1, 1588,    2, 0x0a,  199 /* Public */,
     153,    1, 1591,    2, 0x0a,  201 /* Public */,
     154,    0, 1594,    2, 0x0a,  203 /* Public */,
     155,    0, 1595,    2, 0x0a,  204 /* Public */,
     156,    0, 1596,    2, 0x0a,  205 /* Public */,
     157,    0, 1597,    2, 0x0a,  206 /* Public */,
     158,    0, 1598,    2, 0x0a,  207 /* Public */,
     159,    0, 1599,    2, 0x0a,  208 /* Public */,
     160,    0, 1600,    2, 0x0a,  209 /* Public */,
     161,    0, 1601,    2, 0x0a,  210 /* Public */,
     162,    0, 1602,    2, 0x0a,  211 /* Public */,
     163,    0, 1603,    2, 0x0a,  212 /* Public */,
     164,    0, 1604,    2, 0x0a,  213 /* Public */,
     165,    0, 1605,    2, 0x0a,  214 /* Public */,
     166,    0, 1606,    2, 0x0a,  215 /* Public */,
     167,    0, 1607,    2, 0x0a,  216 /* Public */,
     168,    0, 1608,    2, 0x0a,  217 /* Public */,
     169,    0, 1609,    2, 0x0a,  218 /* Public */,
     170,    0, 1610,    2, 0x0a,  219 /* Public */,
     171,    0, 1611,    2, 0x0a,  220 /* Public */,
     172,    0, 1612,    2, 0x0a,  221 /* Public */,
     173,    0, 1613,    2, 0x0a,  222 /* Public */,
     174,    0, 1614,    2, 0x0a,  223 /* Public */,
     175,    0, 1615,    2, 0x0a,  224 /* Public */,
     176,    0, 1616,    2, 0x0a,  225 /* Public */,
     177,    0, 1617,    2, 0x0a,  226 /* Public */,
     178,    0, 1618,    2, 0x0a,  227 /* Public */,
     179,    0, 1619,    2, 0x0a,  228 /* Public */,
     180,    0, 1620,    2, 0x0a,  229 /* Public */,
     181,    0, 1621,    2, 0x0a,  230 /* Public */,
     182,    0, 1622,    2, 0x0a,  231 /* Public */,
     183,    0, 1623,    2, 0x0a,  232 /* Public */,
     184,    0, 1624,    2, 0x0a,  233 /* Public */,
     185,    0, 1625,    2, 0x0a,  234 /* Public */,
     186,    0, 1626,    2, 0x0a,  235 /* Public */,
     187,    0, 1627,    2, 0x0a,  236 /* Public */,
     188,    0, 1628,    2, 0x0a,  237 /* Public */,
     189,    0, 1629,    2, 0x0a,  238 /* Public */,
     190,    0, 1630,    2, 0x0a,  239 /* Public */,
     191,    0, 1631,    2, 0x0a,  240 /* Public */,
     192,    0, 1632,    2, 0x0a,  241 /* Public */,
     193,    0, 1633,    2, 0x0a,  242 /* Public */,
     194,    0, 1634,    2, 0x0a,  243 /* Public */,
     195,    0, 1635,    2, 0x0a,  244 /* Public */,
     196,    0, 1636,    2, 0x0a,  245 /* Public */,
     197,    0, 1637,    2, 0x0a,  246 /* Public */,
     198,    0, 1638,    2, 0x0a,  247 /* Public */,
     199,    0, 1639,    2, 0x0a,  248 /* Public */,
     200,    0, 1640,    2, 0x0a,  249 /* Public */,
     201,    0, 1641,    2, 0x0a,  250 /* Public */,
     202,    0, 1642,    2, 0x0a,  251 /* Public */,
     203,    0, 1643,    2, 0x0a,  252 /* Public */,
     204,    0, 1644,    2, 0x0a,  253 /* Public */,
     205,    0, 1645,    2, 0x0a,  254 /* Public */,
     206,    0, 1646,    2, 0x0a,  255 /* Public */,
     207,    0, 1647,    2, 0x0a,  256 /* Public */,
     208,    0, 1648,    2, 0x0a,  257 /* Public */,
     209,    0, 1649,    2, 0x0a,  258 /* Public */,
     210,    0, 1650,    2, 0x0a,  259 /* Public */,
     211,    0, 1651,    2, 0x0a,  260 /* Public */,
     212,    0, 1652,    2, 0x0a,  261 /* Public */,
     213,    0, 1653,    2, 0x0a,  262 /* Public */,
     214,    0, 1654,    2, 0x0a,  263 /* Public */,
     215,    0, 1655,    2, 0x0a,  264 /* Public */,
     216,    0, 1656,    2, 0x0a,  265 /* Public */,
     217,    0, 1657,    2, 0x0a,  266 /* Public */,
     218,    0, 1658,    2, 0x0a,  267 /* Public */,
     219,    0, 1659,    2, 0x0a,  268 /* Public */,
     220,    0, 1660,    2, 0x0a,  269 /* Public */,
     221,    0, 1661,    2, 0x0a,  270 /* Public */,
     222,    0, 1662,    2, 0x0a,  271 /* Public */,
     223,    0, 1663,    2, 0x0a,  272 /* Public */,
     224,    0, 1664,    2, 0x0a,  273 /* Public */,
     225,    0, 1665,    2, 0x0a,  274 /* Public */,
     226,    0, 1666,    2, 0x0a,  275 /* Public */,
     227,    0, 1667,    2, 0x0a,  276 /* Public */,
     228,    0, 1668,    2, 0x0a,  277 /* Public */,
     229,    0, 1669,    2, 0x0a,  278 /* Public */,
     230,    0, 1670,    2, 0x0a,  279 /* Public */,
     231,    0, 1671,    2, 0x0a,  280 /* Public */,
     232,    0, 1672,    2, 0x0a,  281 /* Public */,
     233,    0, 1673,    2, 0x0a,  282 /* Public */,
     234,    0, 1674,    2, 0x0a,  283 /* Public */,
     235,    0, 1675,    2, 0x0a,  284 /* Public */,
     236,    0, 1676,    2, 0x0a,  285 /* Public */,
     237,    2, 1677,    2, 0x0a,  286 /* Public */,
     237,    1, 1682,    2, 0x2a,  289 /* Public | MethodCloned */,
     239,    1, 1685,    2, 0x0a,  291 /* Public */,
     240,    1, 1688,    2, 0x0a,  293 /* Public */,
     241,    0, 1691,    2, 0x0a,  295 /* Public */,
     242,    1, 1692,    2, 0x0a,  296 /* Public */,
     244,    1, 1695,    2, 0x0a,  298 /* Public */,
     245,    1, 1698,    2, 0x0a,  300 /* Public */,
     246,    0, 1701,    2, 0x08,  302 /* Private */,
     247,    1, 1702,    2, 0x08,  303 /* Private */,
     248,    0, 1705,    2, 0x08,  305 /* Private */,
     249,    0, 1706,    2, 0x08,  306 /* Private */,
     250,    0, 1707,    2, 0x08,  307 /* Private */,
     251,    0, 1708,    2, 0x08,  308 /* Private */,
     252,    0, 1709,    2, 0x08,  309 /* Private */,
     253,    0, 1710,    2, 0x08,  310 /* Private */,
     254,    0, 1711,    2, 0x08,  311 /* Private */,
     255,    0, 1712,    2, 0x08,  312 /* Private */,
     256,    0, 1713,    2, 0x08,  313 /* Private */,
       7,    1, 1714,    2, 0x08,  314 /* Private */,
     258,    1, 1717,    2, 0x08,  316 /* Private */,
     259,    0, 1720,    2, 0x08,  318 /* Private */,
     260,    1, 1721,    2, 0x08,  319 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::Int, QMetaType::QString,    2,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Char,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void, QMetaType::QReal,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::QByteArray,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::QString,   37,
    QMetaType::Void, QMetaType::QString,   39,
    QMetaType::Void, QMetaType::Int,   41,
    QMetaType::Void, QMetaType::Int,   43,
    QMetaType::Void, QMetaType::QString,   45,
    QMetaType::Void, QMetaType::QString,   47,
    QMetaType::Void, QMetaType::QString,   49,
    QMetaType::Void, QMetaType::QString,   51,
    QMetaType::Void, QMetaType::QString,   53,
    QMetaType::Void, QMetaType::QString,   55,
    QMetaType::Void, QMetaType::QString,   57,
    QMetaType::Void, QMetaType::QString,   59,
    QMetaType::Void, QMetaType::QString,   61,
    QMetaType::Void, QMetaType::QString,   63,
    QMetaType::Void, QMetaType::QString,   65,
    QMetaType::Void, QMetaType::QString,   67,
    QMetaType::Void, QMetaType::QString,   69,
    QMetaType::Void, QMetaType::QString,   71,
    QMetaType::Void, QMetaType::Int,   73,
    QMetaType::Void, QMetaType::QString,   75,
    QMetaType::Void, QMetaType::QString,   77,
    QMetaType::Void, QMetaType::QReal,   79,
    QMetaType::Void, QMetaType::Bool,   81,
    QMetaType::Void, QMetaType::QString,   83,
    QMetaType::Void, QMetaType::QString,   85,
    QMetaType::Void, QMetaType::QString,   87,
    QMetaType::Void, QMetaType::QString,   89,
    QMetaType::Void, QMetaType::QString,   91,
    QMetaType::Void, QMetaType::QString,   81,
    QMetaType::Void, QMetaType::Bool,   94,
    QMetaType::Void, QMetaType::Bool,   94,
    QMetaType::Void, QMetaType::Bool,   97,
    QMetaType::Void, QMetaType::QString,   99,
    QMetaType::Void, QMetaType::QString,  101,
    QMetaType::Void, QMetaType::QString,  103,
    QMetaType::Void, QMetaType::QString,  105,
    QMetaType::Void, QMetaType::Bool,  107,
    QMetaType::Void, QMetaType::Bool,  109,
    QMetaType::Void, QMetaType::Bool,  111,
    QMetaType::Void, QMetaType::Bool,  113,
    QMetaType::Void, QMetaType::QString,  115,
    QMetaType::Void, QMetaType::QString,  117,
    QMetaType::Void, QMetaType::Bool,  119,
    QMetaType::Void, QMetaType::QString,  121,
    QMetaType::Void, QMetaType::QString,  121,
    QMetaType::Void, QMetaType::QString,  121,
    QMetaType::Void, QMetaType::QString,  121,
    QMetaType::Void, QMetaType::QString,  121,
    QMetaType::Void, QMetaType::QString,  121,
    QMetaType::Void, QMetaType::QString,  121,
    QMetaType::Void, QMetaType::QString,  121,
    QMetaType::Void, QMetaType::QString,  121,
    QMetaType::Void, QMetaType::QString,  121,
    QMetaType::Void, QMetaType::QString,  121,
    QMetaType::Void, QMetaType::QString,  121,
    QMetaType::Void, QMetaType::QString,  121,
    QMetaType::Void, QMetaType::QString,  121,
    QMetaType::Void, QMetaType::QString,  121,
    QMetaType::Void, QMetaType::QString,  121,
    QMetaType::Void, QMetaType::QString,  121,
    QMetaType::Void, QMetaType::QString,  121,
    QMetaType::Void, QMetaType::Bool,  139,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,  121,
    QMetaType::Void, QMetaType::QString,  152,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Bool,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QStringList,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::Bool,
    QMetaType::Bool,
    QMetaType::Bool,
    QMetaType::QString,
    QMetaType::QStringList,
    QMetaType::QStringList,
    QMetaType::QStringList,
    QMetaType::QStringList,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::Void,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::Void, QMetaType::QString, QMetaType::Bool,    2,  238,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::UShort,
    QMetaType::Void, QMetaType::UShort,  243,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 257,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::UShort,  243,

       0        // eod
};

Q_CONSTINIT const QMetaObject DroidStar::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_DroidStar.offsetsAndSizes,
    qt_meta_data_DroidStar,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_DroidStar_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<DroidStar, std::true_type>,
        // method 'input_source_changed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'mode_changed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'module_changed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<char, std::false_type>,
        // method 'slot_changed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'cc_changed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'update_data'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'update_log'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'open_vocoder_dialog'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'update_settings'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'connect_status_changed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'in_audio_vol_changed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<qreal, std::false_type>,
        // method 'tx_pressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'tx_released'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'tx_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'dmrpc_state_changed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'dmr_tgid_changed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'm17_rate_changed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'm17_can_changed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'send_dtmf'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QByteArray, std::false_type>,
        // method 'swtx_state_changed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'swrx_state_changed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'swtx_state'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'swrx_state'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'agc_state'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'agc_state_changed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'rptr1_changed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'rptr2_changed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'mycall_changed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'urcall_changed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'usrtxt_changed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'dst_changed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'debug_changed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'update_devices'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'set_callsign'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'set_dmrtgid'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'set_slot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const int, std::false_type>,
        // method 'set_cc'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const int, std::false_type>,
        // method 'tgid_text_changed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'set_dmrid'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'set_essid'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'set_bm_password'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'set_tgif_password'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'set_latitude'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'set_longitude'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'set_location'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'set_description'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'set_freq'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'set_url'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'set_swid'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'set_pkgid'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'set_dmr_options'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'set_dmr_pc'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'set_module'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'set_protocol'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'set_input_volume'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<qreal, std::false_type>,
        // method 'set_modelchange'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'set_mycall'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'set_urcall'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'set_rptr1'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'set_rptr2'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'set_usrtxt'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'set_txtimeout'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'set_toggletx'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'set_xrf2ref'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'set_ipv6'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'set_vocoder'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'set_modem'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'set_playback'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'set_capture'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'set_swtx'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'set_swrx'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'set_agc'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'set_mmdvm_direct'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'set_iaxport'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'set_dst'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'set_debug'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'set_modemRxFreq'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'set_modemTxFreq'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'set_modemRxOffset'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'set_modemTxOffset'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'set_modemRxDCOffset'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'set_modemTxDCOffset'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'set_modemRxLevel'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'set_modemTxLevel'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'set_modemRFLevel'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'set_modemTxDelay'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'set_modemCWIdTxLevel'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'set_modemDstarTxLevel'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'set_modemDMRTxLevel'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'set_modemYSFTxLevel'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'set_modemP25TxLevel'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'set_modemNXDNTxLevel'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'set_modemBaud'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'set_modemM17CAN'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'm17_rate_changed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'process_connect'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'press_tx'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'release_tx'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'click_tx'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'process_settings'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'check_host_files'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'update_host_files'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'update_custom_hosts'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'update_dmr_ids'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'update_nxdn_ids'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'process_mode_change'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'process_host_change'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'dtmf_send_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_modelchange'
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'get_label1'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_label2'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_label3'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_label4'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_label5'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_label6'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_data1'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_data2'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_data3'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_data4'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_data5'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_data6'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_ambestatustxt'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_mmdvmstatustxt'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_netstatustxt'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_mode'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_host'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_module'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_callsign'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_dmrid'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_essid'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_bm_password'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_tgif_password'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_latitude'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_longitude'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_location'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_description'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_freq'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_url'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_swid'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_pkgid'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_dmr_options'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_dmrtgid'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_hosts'
        QtPrivate::TypeAndForceComplete<QStringList, std::false_type>,
        // method 'get_ref_host'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_dcs_host'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_xrf_host'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_ysf_host'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_fcs_host'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_dmr_host'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_p25_host'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_nxdn_host'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_m17_host'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_iax_host'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_mycall'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_urcall'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_rptr1'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_rptr2'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_txtimeout'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_error_text'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_toggletx'
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'get_ipv6'
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'get_xrf2ref'
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'get_local_hosts'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_vocoders'
        QtPrivate::TypeAndForceComplete<QStringList, std::false_type>,
        // method 'get_modems'
        QtPrivate::TypeAndForceComplete<QStringList, std::false_type>,
        // method 'get_playbacks'
        QtPrivate::TypeAndForceComplete<QStringList, std::false_type>,
        // method 'get_captures'
        QtPrivate::TypeAndForceComplete<QStringList, std::false_type>,
        // method 'get_modemRxFreq'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_modemTxFreq'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_modemRxOffset'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_modemTxOffset'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_modemRxDCOffset'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_modemTxDCOffset'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_modemRxLevel'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_modemTxLevel'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_modemRFLevel'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_modemTxDelay'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_modemCWIdTxLevel'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_modemDstarTxLevel'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_modemDMRTxLevel'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_modemYSFTxLevel'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_modemP25TxLevel'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_modemNXDNTxLevel'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_modemBaud'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_modemM17CAN'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_platform'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'reset_connect_status'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'get_monofont'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_arch'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_build_abi'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_software_build'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'download_file'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'download_file'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'file_downloaded'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'url_downloaded'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'get_output_level'
        QtPrivate::TypeAndForceComplete<unsigned short, std::false_type>,
        // method 'set_output_level'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<unsigned short, std::false_type>,
        // method 'tts_changed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'tts_text_changed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'discover_devices'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'process_dstar_hosts'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'process_ysf_hosts'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'process_fcs_rooms'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'process_dmr_hosts'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'process_p25_hosts'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'process_nxdn_hosts'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'process_m17_hosts'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'process_iax_hosts'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'process_dmr_ids'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'process_nxdn_ids'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'update_data'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<Mode::MODEINFO, std::false_type>,
        // method 'updatelog'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'save_settings'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'update_output_level'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<unsigned short, std::false_type>
    >,
    nullptr
} };

void DroidStar::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<DroidStar *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->input_source_changed((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2]))); break;
        case 1: _t->mode_changed(); break;
        case 2: _t->module_changed((*reinterpret_cast< std::add_pointer_t<char>>(_a[1]))); break;
        case 3: _t->slot_changed((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 4: _t->cc_changed((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 5: _t->update_data(); break;
        case 6: _t->update_log((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 7: _t->open_vocoder_dialog(); break;
        case 8: _t->update_settings(); break;
        case 9: _t->connect_status_changed((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 10: _t->in_audio_vol_changed((*reinterpret_cast< std::add_pointer_t<qreal>>(_a[1]))); break;
        case 11: _t->tx_pressed(); break;
        case 12: _t->tx_released(); break;
        case 13: _t->tx_clicked((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 14: _t->dmrpc_state_changed((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 15: _t->dmr_tgid_changed((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 16: _t->m17_rate_changed((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 17: _t->m17_can_changed((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 18: _t->send_dtmf((*reinterpret_cast< std::add_pointer_t<QByteArray>>(_a[1]))); break;
        case 19: _t->swtx_state_changed((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 20: _t->swrx_state_changed((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 21: _t->swtx_state((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 22: _t->swrx_state((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 23: _t->agc_state((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 24: _t->agc_state_changed((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 25: _t->rptr1_changed((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 26: _t->rptr2_changed((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 27: _t->mycall_changed((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 28: _t->urcall_changed((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 29: _t->usrtxt_changed((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 30: _t->dst_changed((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 31: _t->debug_changed((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 32: _t->update_devices(); break;
        case 33: _t->set_callsign((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 34: _t->set_dmrtgid((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 35: _t->set_slot((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 36: _t->set_cc((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 37: _t->tgid_text_changed((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 38: _t->set_dmrid((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 39: _t->set_essid((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 40: _t->set_bm_password((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 41: _t->set_tgif_password((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 42: _t->set_latitude((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 43: _t->set_longitude((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 44: _t->set_location((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 45: _t->set_description((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 46: _t->set_freq((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 47: _t->set_url((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 48: _t->set_swid((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 49: _t->set_pkgid((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 50: _t->set_dmr_options((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 51: _t->set_dmr_pc((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 52: _t->set_module((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 53: _t->set_protocol((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 54: _t->set_input_volume((*reinterpret_cast< std::add_pointer_t<qreal>>(_a[1]))); break;
        case 55: _t->set_modelchange((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 56: _t->set_mycall((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 57: _t->set_urcall((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 58: _t->set_rptr1((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 59: _t->set_rptr2((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 60: _t->set_usrtxt((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 61: _t->set_txtimeout((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 62: _t->set_toggletx((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 63: _t->set_xrf2ref((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 64: _t->set_ipv6((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 65: _t->set_vocoder((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 66: _t->set_modem((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 67: _t->set_playback((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 68: _t->set_capture((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 69: _t->set_swtx((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 70: _t->set_swrx((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 71: _t->set_agc((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 72: _t->set_mmdvm_direct((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 73: _t->set_iaxport((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 74: _t->set_dst((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 75: _t->set_debug((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 76: _t->set_modemRxFreq((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 77: _t->set_modemTxFreq((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 78: _t->set_modemRxOffset((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 79: _t->set_modemTxOffset((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 80: _t->set_modemRxDCOffset((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 81: _t->set_modemTxDCOffset((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 82: _t->set_modemRxLevel((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 83: _t->set_modemTxLevel((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 84: _t->set_modemRFLevel((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 85: _t->set_modemTxDelay((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 86: _t->set_modemCWIdTxLevel((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 87: _t->set_modemDstarTxLevel((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 88: _t->set_modemDMRTxLevel((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 89: _t->set_modemYSFTxLevel((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 90: _t->set_modemP25TxLevel((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 91: _t->set_modemNXDNTxLevel((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 92: _t->set_modemBaud((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 93: _t->set_modemM17CAN((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 94: _t->m17_rate_changed((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 95: _t->process_connect(); break;
        case 96: _t->press_tx(); break;
        case 97: _t->release_tx(); break;
        case 98: _t->click_tx((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 99: _t->process_settings(); break;
        case 100: _t->check_host_files(); break;
        case 101: _t->update_host_files(); break;
        case 102: _t->update_custom_hosts((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 103: _t->update_dmr_ids(); break;
        case 104: _t->update_nxdn_ids(); break;
        case 105: _t->process_mode_change((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 106: _t->process_host_change((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 107: _t->dtmf_send_clicked((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 108: { bool _r = _t->get_modelchange();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 109: { QString _r = _t->get_label1();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 110: { QString _r = _t->get_label2();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 111: { QString _r = _t->get_label3();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 112: { QString _r = _t->get_label4();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 113: { QString _r = _t->get_label5();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 114: { QString _r = _t->get_label6();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 115: { QString _r = _t->get_data1();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 116: { QString _r = _t->get_data2();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 117: { QString _r = _t->get_data3();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 118: { QString _r = _t->get_data4();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 119: { QString _r = _t->get_data5();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 120: { QString _r = _t->get_data6();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 121: { QString _r = _t->get_ambestatustxt();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 122: { QString _r = _t->get_mmdvmstatustxt();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 123: { QString _r = _t->get_netstatustxt();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 124: { QString _r = _t->get_mode();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 125: { QString _r = _t->get_host();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 126: { QString _r = _t->get_module();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 127: { QString _r = _t->get_callsign();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 128: { QString _r = _t->get_dmrid();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 129: { QString _r = _t->get_essid();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 130: { QString _r = _t->get_bm_password();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 131: { QString _r = _t->get_tgif_password();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 132: { QString _r = _t->get_latitude();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 133: { QString _r = _t->get_longitude();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 134: { QString _r = _t->get_location();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 135: { QString _r = _t->get_description();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 136: { QString _r = _t->get_freq();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 137: { QString _r = _t->get_url();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 138: { QString _r = _t->get_swid();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 139: { QString _r = _t->get_pkgid();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 140: { QString _r = _t->get_dmr_options();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 141: { QString _r = _t->get_dmrtgid();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 142: { QStringList _r = _t->get_hosts();
            if (_a[0]) *reinterpret_cast< QStringList*>(_a[0]) = std::move(_r); }  break;
        case 143: { QString _r = _t->get_ref_host();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 144: { QString _r = _t->get_dcs_host();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 145: { QString _r = _t->get_xrf_host();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 146: { QString _r = _t->get_ysf_host();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 147: { QString _r = _t->get_fcs_host();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 148: { QString _r = _t->get_dmr_host();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 149: { QString _r = _t->get_p25_host();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 150: { QString _r = _t->get_nxdn_host();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 151: { QString _r = _t->get_m17_host();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 152: { QString _r = _t->get_iax_host();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 153: { QString _r = _t->get_mycall();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 154: { QString _r = _t->get_urcall();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 155: { QString _r = _t->get_rptr1();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 156: { QString _r = _t->get_rptr2();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 157: { QString _r = _t->get_txtimeout();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 158: { QString _r = _t->get_error_text();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 159: { bool _r = _t->get_toggletx();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 160: { bool _r = _t->get_ipv6();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 161: { bool _r = _t->get_xrf2ref();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 162: { QString _r = _t->get_local_hosts();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 163: { QStringList _r = _t->get_vocoders();
            if (_a[0]) *reinterpret_cast< QStringList*>(_a[0]) = std::move(_r); }  break;
        case 164: { QStringList _r = _t->get_modems();
            if (_a[0]) *reinterpret_cast< QStringList*>(_a[0]) = std::move(_r); }  break;
        case 165: { QStringList _r = _t->get_playbacks();
            if (_a[0]) *reinterpret_cast< QStringList*>(_a[0]) = std::move(_r); }  break;
        case 166: { QStringList _r = _t->get_captures();
            if (_a[0]) *reinterpret_cast< QStringList*>(_a[0]) = std::move(_r); }  break;
        case 167: { QString _r = _t->get_modemRxFreq();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 168: { QString _r = _t->get_modemTxFreq();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 169: { QString _r = _t->get_modemRxOffset();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 170: { QString _r = _t->get_modemTxOffset();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 171: { QString _r = _t->get_modemRxDCOffset();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 172: { QString _r = _t->get_modemTxDCOffset();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 173: { QString _r = _t->get_modemRxLevel();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 174: { QString _r = _t->get_modemTxLevel();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 175: { QString _r = _t->get_modemRFLevel();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 176: { QString _r = _t->get_modemTxDelay();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 177: { QString _r = _t->get_modemCWIdTxLevel();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 178: { QString _r = _t->get_modemDstarTxLevel();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 179: { QString _r = _t->get_modemDMRTxLevel();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 180: { QString _r = _t->get_modemYSFTxLevel();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 181: { QString _r = _t->get_modemP25TxLevel();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 182: { QString _r = _t->get_modemNXDNTxLevel();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 183: { QString _r = _t->get_modemBaud();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 184: { QString _r = _t->get_modemM17CAN();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 185: { QString _r = _t->get_platform();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 186: _t->reset_connect_status(); break;
        case 187: { QString _r = _t->get_monofont();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 188: { QString _r = _t->get_arch();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 189: { QString _r = _t->get_build_abi();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 190: { QString _r = _t->get_software_build();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 191: _t->download_file((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[2]))); break;
        case 192: _t->download_file((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 193: _t->file_downloaded((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 194: _t->url_downloaded((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 195: { ushort _r = _t->get_output_level();
            if (_a[0]) *reinterpret_cast< ushort*>(_a[0]) = std::move(_r); }  break;
        case 196: _t->set_output_level((*reinterpret_cast< std::add_pointer_t<ushort>>(_a[1]))); break;
        case 197: _t->tts_changed((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 198: _t->tts_text_changed((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 199: _t->discover_devices(); break;
        case 200: _t->process_dstar_hosts((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 201: _t->process_ysf_hosts(); break;
        case 202: _t->process_fcs_rooms(); break;
        case 203: _t->process_dmr_hosts(); break;
        case 204: _t->process_p25_hosts(); break;
        case 205: _t->process_nxdn_hosts(); break;
        case 206: _t->process_m17_hosts(); break;
        case 207: _t->process_iax_hosts(); break;
        case 208: _t->process_dmr_ids(); break;
        case 209: _t->process_nxdn_ids(); break;
        case 210: _t->update_data((*reinterpret_cast< std::add_pointer_t<Mode::MODEINFO>>(_a[1]))); break;
        case 211: _t->updatelog((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 212: _t->save_settings(); break;
        case 213: _t->update_output_level((*reinterpret_cast< std::add_pointer_t<ushort>>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (DroidStar::*)(int , QString );
            if (_t _q_method = &DroidStar::input_source_changed; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (DroidStar::*)();
            if (_t _q_method = &DroidStar::mode_changed; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (DroidStar::*)(char );
            if (_t _q_method = &DroidStar::module_changed; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (DroidStar::*)(int );
            if (_t _q_method = &DroidStar::slot_changed; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (DroidStar::*)(int );
            if (_t _q_method = &DroidStar::cc_changed; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (DroidStar::*)();
            if (_t _q_method = &DroidStar::update_data; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (DroidStar::*)(QString );
            if (_t _q_method = &DroidStar::update_log; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (DroidStar::*)();
            if (_t _q_method = &DroidStar::open_vocoder_dialog; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (DroidStar::*)();
            if (_t _q_method = &DroidStar::update_settings; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (DroidStar::*)(int );
            if (_t _q_method = &DroidStar::connect_status_changed; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 9;
                return;
            }
        }
        {
            using _t = void (DroidStar::*)(qreal );
            if (_t _q_method = &DroidStar::in_audio_vol_changed; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 10;
                return;
            }
        }
        {
            using _t = void (DroidStar::*)();
            if (_t _q_method = &DroidStar::tx_pressed; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 11;
                return;
            }
        }
        {
            using _t = void (DroidStar::*)();
            if (_t _q_method = &DroidStar::tx_released; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 12;
                return;
            }
        }
        {
            using _t = void (DroidStar::*)(bool );
            if (_t _q_method = &DroidStar::tx_clicked; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 13;
                return;
            }
        }
        {
            using _t = void (DroidStar::*)(int );
            if (_t _q_method = &DroidStar::dmrpc_state_changed; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 14;
                return;
            }
        }
        {
            using _t = void (DroidStar::*)(int );
            if (_t _q_method = &DroidStar::dmr_tgid_changed; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 15;
                return;
            }
        }
        {
            using _t = void (DroidStar::*)(int );
            if (_t _q_method = &DroidStar::m17_rate_changed; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 16;
                return;
            }
        }
        {
            using _t = void (DroidStar::*)(int );
            if (_t _q_method = &DroidStar::m17_can_changed; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 17;
                return;
            }
        }
        {
            using _t = void (DroidStar::*)(QByteArray );
            if (_t _q_method = &DroidStar::send_dtmf; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 18;
                return;
            }
        }
        {
            using _t = void (DroidStar::*)(int );
            if (_t _q_method = &DroidStar::swtx_state_changed; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 19;
                return;
            }
        }
        {
            using _t = void (DroidStar::*)(int );
            if (_t _q_method = &DroidStar::swrx_state_changed; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 20;
                return;
            }
        }
        {
            using _t = void (DroidStar::*)(int );
            if (_t _q_method = &DroidStar::swtx_state; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 21;
                return;
            }
        }
        {
            using _t = void (DroidStar::*)(int );
            if (_t _q_method = &DroidStar::swrx_state; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 22;
                return;
            }
        }
        {
            using _t = void (DroidStar::*)(int );
            if (_t _q_method = &DroidStar::agc_state; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 23;
                return;
            }
        }
        {
            using _t = void (DroidStar::*)(int );
            if (_t _q_method = &DroidStar::agc_state_changed; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 24;
                return;
            }
        }
        {
            using _t = void (DroidStar::*)(QString );
            if (_t _q_method = &DroidStar::rptr1_changed; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 25;
                return;
            }
        }
        {
            using _t = void (DroidStar::*)(QString );
            if (_t _q_method = &DroidStar::rptr2_changed; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 26;
                return;
            }
        }
        {
            using _t = void (DroidStar::*)(QString );
            if (_t _q_method = &DroidStar::mycall_changed; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 27;
                return;
            }
        }
        {
            using _t = void (DroidStar::*)(QString );
            if (_t _q_method = &DroidStar::urcall_changed; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 28;
                return;
            }
        }
        {
            using _t = void (DroidStar::*)(QString );
            if (_t _q_method = &DroidStar::usrtxt_changed; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 29;
                return;
            }
        }
        {
            using _t = void (DroidStar::*)(QString );
            if (_t _q_method = &DroidStar::dst_changed; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 30;
                return;
            }
        }
        {
            using _t = void (DroidStar::*)(bool );
            if (_t _q_method = &DroidStar::debug_changed; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 31;
                return;
            }
        }
        {
            using _t = void (DroidStar::*)();
            if (_t _q_method = &DroidStar::update_devices; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 32;
                return;
            }
        }
    }
}

const QMetaObject *DroidStar::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *DroidStar::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_DroidStar.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int DroidStar::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 214)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 214;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 214)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 214;
    }
    return _id;
}

// SIGNAL 0
void DroidStar::input_source_changed(int _t1, QString _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void DroidStar::mode_changed()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void DroidStar::module_changed(char _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void DroidStar::slot_changed(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void DroidStar::cc_changed(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void DroidStar::update_data()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}

// SIGNAL 6
void DroidStar::update_log(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void DroidStar::open_vocoder_dialog()
{
    QMetaObject::activate(this, &staticMetaObject, 7, nullptr);
}

// SIGNAL 8
void DroidStar::update_settings()
{
    QMetaObject::activate(this, &staticMetaObject, 8, nullptr);
}

// SIGNAL 9
void DroidStar::connect_status_changed(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 9, _a);
}

// SIGNAL 10
void DroidStar::in_audio_vol_changed(qreal _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 10, _a);
}

// SIGNAL 11
void DroidStar::tx_pressed()
{
    QMetaObject::activate(this, &staticMetaObject, 11, nullptr);
}

// SIGNAL 12
void DroidStar::tx_released()
{
    QMetaObject::activate(this, &staticMetaObject, 12, nullptr);
}

// SIGNAL 13
void DroidStar::tx_clicked(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 13, _a);
}

// SIGNAL 14
void DroidStar::dmrpc_state_changed(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 14, _a);
}

// SIGNAL 15
void DroidStar::dmr_tgid_changed(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 15, _a);
}

// SIGNAL 16
void DroidStar::m17_rate_changed(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 16, _a);
}

// SIGNAL 17
void DroidStar::m17_can_changed(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 17, _a);
}

// SIGNAL 18
void DroidStar::send_dtmf(QByteArray _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 18, _a);
}

// SIGNAL 19
void DroidStar::swtx_state_changed(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 19, _a);
}

// SIGNAL 20
void DroidStar::swrx_state_changed(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 20, _a);
}

// SIGNAL 21
void DroidStar::swtx_state(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 21, _a);
}

// SIGNAL 22
void DroidStar::swrx_state(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 22, _a);
}

// SIGNAL 23
void DroidStar::agc_state(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 23, _a);
}

// SIGNAL 24
void DroidStar::agc_state_changed(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 24, _a);
}

// SIGNAL 25
void DroidStar::rptr1_changed(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 25, _a);
}

// SIGNAL 26
void DroidStar::rptr2_changed(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 26, _a);
}

// SIGNAL 27
void DroidStar::mycall_changed(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 27, _a);
}

// SIGNAL 28
void DroidStar::urcall_changed(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 28, _a);
}

// SIGNAL 29
void DroidStar::usrtxt_changed(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 29, _a);
}

// SIGNAL 30
void DroidStar::dst_changed(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 30, _a);
}

// SIGNAL 31
void DroidStar::debug_changed(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 31, _a);
}

// SIGNAL 32
void DroidStar::update_devices()
{
    QMetaObject::activate(this, &staticMetaObject, 32, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
